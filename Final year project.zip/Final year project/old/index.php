<?PHP
    header('Location: http://localhost/tutorials/authentication/login.php');
?>