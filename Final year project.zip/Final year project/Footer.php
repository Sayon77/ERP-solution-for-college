<!--  -->

<footer >
    <div class="row p-5 bg-dark">
        
    </div>
</footer>
</body>


<style>
html { overflow-x: hidden; }
.hovering:hover{
    opacity: 0.5 !important;
    transition: 0.3s;
}
</style>
<script src="bootstrap/js/jquery-3.4.1.slim.min.js" ></script>
<script src="bootstrap/js/popper.min.js"></script>
<script src="bootstrap/js/bootstrap.min.js" ></script>
</html>