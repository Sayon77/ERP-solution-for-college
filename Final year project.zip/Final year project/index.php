<?PHP
    // header('Location: http://localhost/tutorials/authentication/login.php');
    include('Header.php');
    include('Footer.php')
?>